from random import randrange

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


class Person:
    def __init__(self, name, hp, mp, attack, defence, magic, ):
        self.maximum_hp = hp
        self.maximum_mp = mp
        self.hp = hp
        self.name = name
        self.defence = defence
        self.mp = mp
        self.attack_low = attack - 5
        self.attack_high = attack + 20
        self.magic = magic
        self.actions = ['Attack', 'Magic']
        # self.item = item

    def generate_damage(self):
        return randrange(self.attack_low, self.attack_high)

    def take_damage(self, damage):
        self.hp -= damage
        if self.hp < 0:
            self.hp = 0
        return self.hp

    def get_hp(self):
        return self.hp

    def get_maximum_hp(self):
        return self.maximum_hp

    def get_mp(self):
        return self.mp

    def get_maximum_mp(self):
        return self.maximum_mp


    def reduce_magic_point(self, cost):
        self.mp -= cost

    def choose_action(self):
        print(bcolors.HEADER + bcolors.OKGREEN + bcolors.BOLD + "Actions" + bcolors.ENDC)
        i = 1
        for item in self.actions:
            print("{0} : {1}".format(i, item))
            i += 1

    def choose_magic(self):
        print(bcolors.OKBLUE + bcolors.BOLD + "Magic" + bcolors.ENDC)
        i = 1
        for spell in self.magic:
            print(f"{i} : {spell.name}  (cost : {spell.cost})")
            i += 1
    def heal(self,Hp):
        self.hp += Hp
        if self.hp > self.maximum_hp:
            self.hp = self.maximum_hp

    def Level(self):
        pass


class Magic:
    def __init__(self,name,cost,damage,type):
        self.name = name
        self.cost = cost
        self.damage = damage
        self.type = type
    def generate_damage(self):
        low = self.damage - 15
        high = self.damage +15
        return randrange(low,high)