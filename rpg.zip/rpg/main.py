from classes.game import Person, bcolors, Magic

fire = Magic("Fire", 8, 100, 'Black')
blizzard = Magic("Blizard", 12, 150, 'Black')
thunder = Magic("Thunder", 10, 120, 'Black')
meteor = Magic("Meteor", 15, 160, 'Black')
quake = Magic("Quake", 20, 250, 'Black')
cure = Magic("Cure", 12, 120, "White")
cura = Magic("Cura", 18, 200, "White")

player = Person(input("Enter Player name : ").capitalize(), 1000, 65, 60, 34, [fire, blizzard, thunder, meteor, cure, cura])
enemy = Person("Enemy", 2000, 65, 45, 25, [])
print(bcolors.FAIL + bcolors.BOLD + "AN ENEMY ATTACK GAME" + bcolors.ENDC, "\n====================")
print(
    f"\nWelcome! {bcolors.OKGREEN + bcolors.BOLD + player.name + bcolors.ENDC}  \n\nMaximum Hp of {player.name} : {player.maximum_hp}\nMaximum Hp of Enemy {enemy.maximum_hp}")
levels = ["Easy", "Medium", "Hard"]
print("---------------------\nDifficulty Levels\n")
for i in enumerate(levels):
    print(f"{i[0] + 1} : {i[1]}")
levels = int(input("Choose Difficulty level : ")) - 1
level_points = {1: 10, 0: 30, 2: 5}
while True:
    player.choose_action()
    try:
        choice_action = int(input("Choose Action : ")) - 1
    except:
        print("Wrong Input!!!  \n")
        continue
    if choice_action == 0:
        Attack_damage = player.generate_damage() + level_points[levels]
        enemy.take_damage(Attack_damage)
        print(f"{bcolors.BOLD}You attack for {Attack_damage} points of damage")
        enemy_damage = enemy.generate_damage() - level_points[levels] + 10
        player.take_damage(enemy_damage)
        print(f"Enemy attack for {enemy_damage} points of damage\n")

    elif choice_action == 1:
        player.choose_magic()
        choice_magic = int(input("Choose Action : ")) - 1
        try:
            spell = player.magic[choice_magic]

        except (IndexError, ValueError):
            print("Wrong Input!!!  \n")
            continue
        magic_damage = spell.generate_damage()

        current_mp = player.get_mp()
        if spell.cost > current_mp:
            print(bcolors.FAIL + "\nNot Enough Magic Points" + bcolors.ENDC)
            continue
        player.reduce_magic_point(spell.cost)
        if spell.type == "White":
            player.heal(magic_damage)
            print(f"player is healed with {magic_damage} Hp")
        else:
            enemy.take_damage(magic_damage)
            print(f"{bcolors.OKBLUE} \n{spell.name} deals {magic_damage} Points of damage {bcolors.ENDC}\n")
            enemy_damage = enemy.generate_damage() - level_points[levels]
            player.take_damage(enemy_damage)
            print(f"Enemy attack for {enemy_damage} points of damage")
    if enemy.get_hp() == 0:
        print(bcolors.OKGREEN + bcolors.BOLD + "\nYou Win".upper() + bcolors.ENDC)
        break
    elif player.get_hp() == 0:
        print(bcolors.FAIL + bcolors.BOLD + " \nGame Over!\n you have been defeated".upper() + bcolors.ENDC)
        break
    print("\n-------------------------------------------------------------------------------------")
    print(f"{bcolors.BOLD}Enemy Hp : {bcolors.OKGREEN}{enemy.get_hp()}/{enemy.get_maximum_hp()}  \n "
          f"{bcolors.ENDC}\n{player.name} Hp : {bcolors.FAIL + bcolors.BOLD}{player.get_hp()}/{player.get_maximum_hp()} "
          f"{bcolors.ENDC}\n{player.name} Mp : {bcolors.OKBLUE + bcolors.BOLD}{player.get_mp()}/{player.get_maximum_mp()}{bcolors.ENDC}")
